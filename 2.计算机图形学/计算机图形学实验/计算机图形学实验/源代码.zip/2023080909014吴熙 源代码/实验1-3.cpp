#include <GL/glut.h>
#include <stdio.h>
#include<math.h>

void colorcube();

GLfloat vertices[][3] = {
    {-1.0, -1.0, -1.0}, {1.0, -1.0, -1.0}, {1.0, 1.0, -1.0}, {-1.0, 1.0, -1.0},
    {-1.0, -1.0, 1.0},  {1.0, -1.0, 1.0},  {1.0, 1.0, 1.0},  {-1.0, 1.0, 1.0}
};

GLfloat colors[][3] = {
    {0.0, 0.0, 0.0}, {1.0, 0.0, 0.0}, {1.0, 1.0, 0.0}, {0.0, 1.0, 0.0},
    {0.0, 0.0, 1.0}, {1.0, 0.0, 1.0}, {1.0, 1.0, 1.0}, {0.0, 1.0, 1.0}
};

GLfloat objectXform[4][4] = {
    {1.0, 0.0, 0.0, 0.0},
    {0.0, 1.0, 0.0, 0.0},
    {0.0, 0.0, 1.0, 0.0},
    {0.0, 0.0, 0.0, 1.0}
};

GLfloat xview = 0.0, yview = 0.0, zview = 0.0;
GLfloat xref = 0.0, yref = 0.0, zref = -1.0;
GLfloat Vx = 0.0, Vy = 1.0, Vz = 0.0;
GLfloat viewxform_x = 0.0, viewxform_y = 0.0, viewxform_z = -5.0;
float mynear = 2.0, myfar = 20.0;
bool drawLines = false;

struct menuEntryStruct {
    const char* label;
    char key;
};

static menuEntryStruct mainMenu[] = {
    {"normal", '2'}, {"left", '4'}, {"right", '6'}, {"back", '8'}, {"top", '5'}
};

int mainMenuEntries = sizeof(mainMenu) / sizeof(menuEntryStruct);

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-2.5, 2.5, -2.5, 2.5, mynear, myfar);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(xview, yview, zview, xref, yref, zref, Vx, Vy, Vz);

    glTranslatef(viewxform_x, viewxform_y, viewxform_z);

    glPushMatrix();
    glTranslatef(0.0, -1.0, 0.0);
    glScalef(5.0, 0.1, 5.0);
    glColor3f(0.5, 0.5, 0.5);
    glutSolidCube(1.0);
    glPopMatrix();

    colorcube();

    glFlush();
    glutSwapBuffers();
}

void polygon(int a, int b, int c, int d, int face) {
    if (drawLines) {
        glColor3f(1.0, 1.0, 1.0);
        glBegin(GL_LINE_LOOP);
        glVertex3fv(vertices[a]);
        glVertex3fv(vertices[b]);
        glVertex3fv(vertices[c]);
        glVertex3fv(vertices[d]);
        glEnd();
    }
    else {
        glBegin(GL_POLYGON);
        glColor3fv(colors[a]);
        glVertex3fv(vertices[a]);

        glColor3fv(colors[b]);
        glVertex3fv(vertices[b]);

        glColor3fv(colors[c]);
        glVertex3fv(vertices[c]);

        glColor3fv(colors[d]);
        glVertex3fv(vertices[d]);

        glEnd();
    }
}

void myReshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-5.0, 5.0, -5.0, 5.0, mynear, myfar);

    glMatrixMode(GL_MODELVIEW);
}

void colorcube() {
    glShadeModel(GL_FLAT);
    polygon(1, 0, 3, 2, 0);
    polygon(3, 7, 6, 2, 1);
    polygon(7, 3, 0, 4, 2);
    polygon(2, 6, 5, 1, 3);
    polygon(4, 5, 6, 7, 4);
    polygon(5, 4, 0, 1, 5);
}

void userEventAction(int key) {
    switch (key) {
    case '2': //ǰ��ͼ
        xview = 0.0; yview = 0.0; zview = 0.0;
        xref = 0.0; yref = 0.0; zref = -6.0;
        Vx = 0.0; Vy = 1.0; Vz = 0.0;
        break;
    case '4':  //����ͼ
        xview = -5.0; yview = 0.0; zview = -5.0;
        xref = 0.0; yref = 0.0; zref = -5.0; 
        Vx = 0.0; Vy = 1.0; Vz = 0.0;  
        break;
    case '6':  // ����ͼ
        xview = 5.0; yview = 0.0; zview = -5.0;
        xref = 0.0; yref = 0.0; zref = -5.0;  
        Vx = 0.0; Vy = 1.0; Vz = 0.0;  
        break;
    case '8':  // ����ͼ
        xview = 0.0; yview = 0.0; zview = -10.0;
        xref = 0.0; yref = 0.0; zref = 0.0;
        Vx = 0.0; Vy = 1.0; Vz = 0.0;
        break;
    case '5':  // ����ͼ
        xview = 0.0; yview = 5.0; zview = -5.0;
        xref = 0.0; yref = 0.0; zref = -5.0;
        Vx = 0.0; Vy = 0.0; Vz = -1.0;
        break;
    }
    glutPostRedisplay();
}

void selectMain(int choice) {
    userEventAction(mainMenu[choice].key);
}

void init() {
    glLineWidth(3.0);
    glEnable(GL_DEPTH_TEST);

    glutCreateMenu(selectMain);
    for (int i = 0; i < mainMenuEntries; i++) {
        glutAddMenuEntry(mainMenu[i].label, i);
    }
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

//���̿����������
void keyboard(unsigned char key, int x, int y) {
    float moveSpeed = 0.5;
    switch (key) {
    case 'w':
        xview += Vx * moveSpeed;
        yview += Vy * moveSpeed;
        zview += Vz * moveSpeed;
        break;
    case 's':
        xview -= Vx * moveSpeed;
        yview -= Vy * moveSpeed;
        zview -= Vz * moveSpeed;
        break;
    case 'a':
        xview -= Vy * moveSpeed;
        yview += Vx * moveSpeed;
        break;
    case 'd':
        xview += Vy * moveSpeed;
        yview -= Vx * moveSpeed;
        break;
    case 'q':
        zview += moveSpeed;
        break;
    case 'e':
        zview -= moveSpeed;
        break;
    }
    glutPostRedisplay();
}

int lastX, lastY;
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        lastX = x;
        lastY = y;
    }
}

void motion(int x, int y) {
    float sensitivity = 0.01;
    float dx = (x - lastX) * sensitivity;
    float dy = (y - lastY) * sensitivity;

    lastX = x;
    lastY = y;

    float sinDy = sin(dy);
    float cosDy = cos(dy);
    float sinDx = sin(dx);
    float cosDx = cos(dx);

    GLfloat newVx = Vx * cosDy + Vz * sinDy;
    GLfloat newVy = Vy * cosDx - Vx * sinDx;
    GLfloat newVz = Vz * cosDy - Vx * sinDy;

    Vx = newVx;
    Vy = newVy;
    Vz = newVz;

    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1000, 1000);
    glutCreateWindow("�۲�任���������");

    init();

    glutDisplayFunc(display);
    glutReshapeFunc(myReshape);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);

    glutMainLoop();
    return 0;
}